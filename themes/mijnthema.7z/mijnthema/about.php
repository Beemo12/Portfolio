<?php
/*
Template Name: About Page
*/
get_header();

the_title();
the_content();


?><?php get_footer(); ?>
