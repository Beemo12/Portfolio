<footer class="site-footer">
    <a href="https://www.linkedin.com/in/yassine-benmeseoud-776653200/" target="_blank">LinkedIn</a>
    <a href="https://github.com/Beemo12" target="_blank">Github</a>
</footer>
<?php wp_footer(); ?>
</body>
</html>
